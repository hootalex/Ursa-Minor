*** WELCOME! ***

Hello wonderful new owner of Whimbrel Caps! 

*** NOTES ***

- For desktop installation you will find the OTF and TTF files most useful. OTF is recommended, but TTF files are available for maximum compatibility. 

*** COLOR FONT ***

- Color fonts are still a new and spottily supported technology as of writing. If you would like to use the color font in Creative Cloud, the SVG file offers the best support. Other apps may vary! 

- Color fonts are almost good to go on web! All of these color font files will work with a CSS embed. The only issue right now is that Chrome doesn't like to scale up color fonts because they assumed color fonts would only be used for emoji. Thankfully the Chrome dev team is working through this bug and it will be fixed in the future!

*** FONT FEATURES ***

- Each character and space takes up the exact same amount of horizontal width. This lets you grid these characters with out a care!

- The number "1" will add a stamp border to your drop cap. Try it out! 

*** CONTACT ***

If you need any help or have any questions, feel free to contact me at 1alextomlinson@gmail.com and I will try to respond as quickly as possible!

*** THANK YOU!!! ***